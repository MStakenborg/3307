Compiled with MinGW The GNU C++ Compiler - mingw32-gcc-g++
Compiled by entereing the following in cmd
g++ asn1.cpp Client.cpp Account.cpp  -o Assignment_1_Group_5_laporte-stakenborg.exe

It should also work in Visual Studio, I wrote the code in there.

The account information for manager:
UserID: manager
PIN: 1111

The account information for maintenance man:
UserID: maintenance
PIN: 1111

Thanks